# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '78ea0199f34a0d7d0c5f53a302d66be4ffc00a3df034ab3d16597e23c58f3f5df3321ad7ebaf4ae517c8d7f4eb83d0a6c7569fd304dc5188ae20260752d67604'

