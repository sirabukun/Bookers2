class BooksController < ApplicationController
  # Book一覧画面の表示
  def index
    @user = current_user
    @books = Book.all  # 一覧表示用
    @book = Book.new  # 投稿用
  end

  # Book詳細画面の表示
  def show
    @book=Book.find(params[:id])
    @book_new = Book.new  # form_withで使う空のモデル
    @user=@book.user
  end

  # Bookの投稿
  def create
    @book=Book.new(books_params)
    @book.user_id = current_user.id  # bookと投稿したユーザー
    if @book.save
      redirect_to book_path(@book.id), notice:'Book was successfully created.'
    else
      @books = Book.all
      @book = Book.new
      @user = current_user
      render :index
    end
  end

  # Book編集画面の表示
  def edit
    @book=Book.find(params[:id])
     # 投稿したユーザーが、ログインしているユーザーではなかったら
    if @book.user_id != current_user.id
      # 投稿一覧へ遷移する
      redirect_to books_path
    end
  end

  # Bookの更新
  def update
    @book = Book.find(params[:id])
    if @book.update(books_params)
      redirect_to book_path(@book.id), notice:'You have updated book successfully.'
    else
      render :edit
    end
  end

  # Bookの削除
  def destroy
    book = Book.find(params[:id])  # データ（レコード）を1件取得
    book.destroy  # データ（レコード）を削除
    redirect_to books_path  # 投稿一覧画面へリダイレクト
  end

  # Bookのストロングパラメータ
  private
  def books_params
    params.require(:book).permit(:title, :body)
  end
end
