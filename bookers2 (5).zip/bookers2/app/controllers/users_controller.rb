class UsersController < ApplicationController
  # ユーザー一覧画面の表示
  def index
    @users = User.all
    @user = current_user
    @book = Book.new  # サイドバーの form_withで使用する
    @books = Book.all
  end

  def show
    @user = User.find(params[:id])
    @book = Book.new  # サイドバーの form_withで使用する
    @books = @user.books.all  # アソシエーションを利用し、当該ユーザーの投稿データを取得している
  end

  # ユーザーの編集画面の表示
  def edit
    @user = User.find(params[:id])
     # 投稿したユーザーが、ログインしているユーザーではなかったら
    if @user != current_user
      # 投稿一覧へ遷移する
      redirect_to user_path(current_user.id)
    end
  end

  # ユーザー情報の更新
  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      redirect_to user_path(@user.id), notice:'You have updated user successfully.'
    else
      render :edit
    end
  end

  # ユーザーのストロングパラメータ
  private
  def user_params
    params.require(:user).permit(:name, :profile_image, :introduction)
  end
end
